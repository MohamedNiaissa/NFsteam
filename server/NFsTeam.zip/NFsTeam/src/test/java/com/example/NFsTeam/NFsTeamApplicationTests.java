package com.example.NFsTeam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NFsTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
